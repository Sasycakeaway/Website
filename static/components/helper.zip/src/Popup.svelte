<script>
  export let message = 'Default message';
</script>

<style>
  h2 {
		font-size: 2rem;
		text-align: center;
	}
</style>

<h2>< {message} <</h2>